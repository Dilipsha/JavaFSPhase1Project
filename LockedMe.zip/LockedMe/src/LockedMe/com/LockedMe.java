package LockedMe.com;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.LinkedList;
import java.util.Scanner;

public class LockedMe {

	static final String projectFilePath="E:\\fio";
	static final String errorMessage="Some error is occured in the program please contact to sharma.dilip137@gmail.com";
	
	static Scanner sc=new Scanner(System.in);
	
	// This Methods will display the Menu items.
	public static void displayMenu()
	 {
	   System.out.println("********************************************");
	   System.out.println("\tWelcome to LockedMe.com\n");
	   System.out.println("********************************************");
	   System.out.println("\tDesigned By Dilip Sharma\n");
	   System.out.println("********************************************");
	   System.out.println("1. Display all the Files :- ");
	   System.out.println("2. Add a New file");
	   System.out.println("3. Delete a file");
	   System.out.println("4. Search a file ");
	   System.out.println("5. Exit.\n ");
	   
	 }
	
	// This method will display all the files.
	public static void getAllFiles()
	 {
		try {
	    File file=new File(projectFilePath);
		File[] listoffiles=file.listFiles();
		
		if(listoffiles.length==0) {
			System.out.println("Does not exist the file.");
		}else {
			
		for(var l:listoffiles)
		{
			System.out.println(l.getName());
		}
	}
	 }catch(Exception ex) {
		 System.out.println(errorMessage);
	 }
 }
	
	// This method will create a new file.
	public static void createFiles()
	 {
		try {
		 String filename;
		 
		 System.out.println("Enter the file name:");
		 filename=sc.nextLine();
		 
		 int linescount;
		 System.out.println("Enter how many lines in the file");
		 linescount=Integer.parseInt(sc.nextLine());
		 
		 FileWriter myWriter=new FileWriter(projectFilePath+ "\\"+filename);
		 for(int i=1;i<=linescount;i++) {
			 System.out.println("Enter the file line:");
			 myWriter.write(sc.nextLine()+"\n");
		 }
		 System.out.println("File is created successfully.");
		 myWriter.close();
		}
		catch(Exception ex) {
			System.out.println(errorMessage);
		}
	 }
	
	// This method will delete the file.
	 public static void deleteFiles()
	 {
		 try {
		 String filename;
		 System.out.println("Enter the file name for delete");
		 filename=sc.nextLine();
		 File file=new File(projectFilePath+ "\\"+filename);
		 if(file.exists()) {
			 file.delete();
			 System.out.println("File is deleted successfully.");
		 }
		else {
			 System.out.println("File is not deleted.");
		    }
	     }
		 catch(Exception ex) 
		 {
			 System.out.println(errorMessage);
		 }
	}
	 
	 // This method will search the file according to user.
	 public static void searchFiles()
	 {
		 try {
			 String filename;
			 System.out.println("Enter file name for search.");
			 filename=sc.nextLine();
			 File file=new File(projectFilePath);
			 File[] listOfFiles=file.listFiles();
			 LinkedList<String> filenames=new LinkedList<String>();
			 for(var l:listOfFiles) {
				 filenames.add(l.getName());
			 }
			 if(filenames.contains(filename))
				 System.out.println("File is available");
			 else
				 System.out.println("File is not available");
			 
		 }catch(Exception e) {
			 System.out.println(errorMessage);
		 }
		
	 }
	
	public static void main(String[] args) {
		
		int ch;
		do {
			displayMenu();
			System.out.println("Enter your choice: ");
		    ch=Integer.parseInt(sc.nextLine());
			
			switch(ch) {
			case 1: getAllFiles();
			break;
			case 2: createFiles();
			break;
			case 3: deleteFiles();
			break;
			case 4: searchFiles();
			break;
			case 5: System.exit(0);
			break;
			default: System.out.println("Invalid Option");
			break;
			}
		}while(ch>0);
		sc.close(); 
		}
	}
